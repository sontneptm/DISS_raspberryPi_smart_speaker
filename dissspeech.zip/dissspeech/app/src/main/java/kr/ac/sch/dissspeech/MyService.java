package kr.ac.sch.dissspeech;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

import com.kakao.sdk.newtoneapi.TextToSpeechListener;
import com.kakao.sdk.newtoneapi.TextToSpeechClient;
import com.kakao.sdk.newtoneapi.TextToSpeechManager;

public class MyService extends Service{
    private TextToSpeechClient ttsClient;
    public boolean talking=false;

    class MyBinder extends Binder {
        MyService getService(){
            return MyService.this;
        }
    }


    IBinder mIBinder = new MyBinder();

    @Override
    public IBinder onBind(Intent intent) {
        Log.e("LOG", "onBind()");
        return mIBinder;
    }
    @Override
    public void onCreate() {
        Log.e("LOG", "onCreate()");
        super.onCreate();

        TextToSpeechManager.getInstance().initializeLibrary(getApplicationContext()); // 음성합성 관리자 초기화

        ttsClient = new TextToSpeechClient.Builder()
                .setAppKey("3badd6419d20a94e03b26297119e4552")
                .setSpeechMode(TextToSpeechClient.NEWTONE_TALK_2)
                .setSpeechSpeed(1.0D)
                .setSpeechVoice(TextToSpeechClient.VOICE_WOMAN_DIALOG_BRIGHT)
                .setListener(new TextToSpeechListener() {
                    @Override
                    public void onFinished() {

                    }

                    @Override
                    public void onError(int code, String message) {

                    }
                })
                .build();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.e("LOG", "onStartCommand()");
        ttsClient.play("하위");
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        Log.e("LOG", "onDestroy()");
        super.onDestroy();
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.e("LOG", "onUnbind()");
        return super.onUnbind(intent);
    }

    public void speach(String text) {
        ttsClient.play(text);
    }

}
